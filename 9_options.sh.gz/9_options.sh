# ! /bin/bash
# Programa para ejemplicar como se realiza el paso de opciones con sin parámetros
# Autor: Rodrigo Huila - @RodrigoHuila


echo "Programa Opciones"
echo "Opción 1 enviada: $1"
echo "Opción 2 enviada: $2"
echo "Opción enviadas: $*"
echo -e "\n"
echo "Recuperar valores"
while [ -n "$1" ]
do
	case "$1" in
		-a) echo "-a opción utilizada";;
		-b) echo "-b opción utilizada";;
		-c) echo "-c opción utilizada";;
		*) echo "$! no es una opción";;
	esac
	shift
done
